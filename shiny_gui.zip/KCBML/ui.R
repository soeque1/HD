library(markdown)

navbarPage("KCB ML Toolkit!",
           navbarMenu("데이터 체크",
                      tabPanel("샘플데이터",
                               DT::dataTableOutput("table")
                      ),
                      tabPanel("유효성 검증",
                               verbatimTextOutput("check")
                      ),
                      tabPanel("데이터 검증",
                               pageWithSidebar(
                                 headerPanel( "변수 검증", "Flowserve"),
                                 sidebarPanel(
                                   selectInput("var", "선택: ","")
                                 ),
                                 mainPanel(verbatimTextOutput("summary"),
                                           sparklineOutput("summary2"),
                                           plotlyOutput("summary3")
                                           
                                 )
                               )
                      )
           ),
           tabPanel("test2",
                    sidebarPanel(
                      sliderInput("values", "Number of values:", min = 5, max = 100, value = 10),
                      selectInput("chart_type", "Chart type", choices = list("line","bar","tristate","box"))
                    ),
                    mainPanel(sparklineOutput("spark"))
           ),
           
           tabPanel("데이터 체크",
                    sidebarLayout(
                      sidebarPanel(
                        radioButtons("plotType", "Plot type",
                                     c("Scatter"="p", "Line"="l")
                        )
                      ),
                      mainPanel(
                        plotOutput("plot")
                      )
                    )
           ),
           tabPanel("1차 Tunning",
                    verbatimTextOutput("cd")
           ),
           tabPanel("2차 Tunning",
                    verbatimTextOutput("b")
           ),
           navbarMenu("기타",
                      tabPanel("KCB ML 패키지 설치",
                               DT::dataTableOutput("table2")
                      ),
                      tabPanel("오류 점검",
                               verbatimTextOutput("dd")
                      )
                      
           )
)

