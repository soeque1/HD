library(data.table)
dt <- fread('data/dt.csv')
#dt <- read.csv('data/dt.csv')

server <- function(input, output, session) {
  
  ## INPUT
  # dataUpload<-reactive({
  # 
  #   inFile<-input$file1
  #   print(inFile)
  #   if(is.null(inFile))
  #     return(NULL)
  #   #dt_frame = read.csv(inFile$datapath, header=input$header, sep=input$sep)
  #   #dt_frame = read.csv(inFile$datapath)
  #   dt_frame <- read.csv('data/dt.csv')
  #   updateSelectInput(session, "product", choices = names(dt_frame))
  #   return(dt_frame)
  # })
  # 
  output$plot <- renderPlot({
    plot(dt$y, type=input$plotType)
  })
  
  output$summary3 <- renderPrint({
    summary(dt)
  })
  
  output$table <- DT::renderDataTable({
    DT::datatable(dt[1:1000,])
  })
  
  # output$summary <- renderPrint({
  #  #  we need error check also here
  #   if(!is.null(input$file1))
  #   {
  #    # dt <- dataUpload()
  #     updateSelectInput(session, "product", choices = colnames(dt))
  #     summary(dt[,input$product])
  #   } 
  #   
  # })
  
  output$summary <- renderPrint({
    updateSelectInput(session, inputId = "var", choices = colnames(dt), selected = input$var)
    
    if(input$var != "")
    {
      var.idx <- which(colnames(dt) == input$var)
      summary(dt[,var.idx, with=F][[1]])
    } else {
      print('변수를 선택하세요')
    }
  })
  
  output$check <- renderPrint({
    str(dt)
  })
  
  output$summary2 <- renderSparkline({
    if(input$var != "")
    {
    #sparkline(dt[,which(colnames(dt) == input$var), with=F][[1]], type = 'bar', width = 600, height = 400)
    sparkline(dt[,which(colnames(dt) == input$var), with=F][[1]], type = 'box', width = 400, height = 200)
    }
  })
  
  output$summary3 <- renderPlotly({
    
    if(input$var != "")
    {
      x <- dt[,which(colnames(dt) == input$var), with=F][[1]]
      
      minx <- min(x)
      maxx <- max(x)
      
      # size of the bins depend on the input 'bins'
      size <- (maxx - minx) / 20 #input$bins
      
      # a simple histogram of movie ratings
      p <- plot_ly(dt, x = ~eval(as.symbol(input$var)), autobinx = F, type = "histogram",
                   xbins = list(start = minx, end = maxx, size = size), width = 400, height = 200)
      # style the xaxis
      layout(p, xaxis = list(title = input$var, range = c(minx, maxx), autorange = F,
                             autotick = F, tick0 = minx, dtick = size))
    } else {
      p <- plot_ly(type = "histogram")
    }
  })
  
}
