rm(list=ls())
library(shiny)
library(sparkline)
library(shiny)
library(plotly)
library(ggplot2)
setwd('C:/repo/shiny_gui')
runApp("KCBML",launch.browser = F, port= 5000)

#setwd('C:/repo/shiny_gui/KCBML/')


## SIMULATION
#set.seed(666)
#x1 = rnorm(1000)           # some continuous variables 
#x2 = rnorm(1000)
#z = 1 + 2*x1 + 3*x2        # linear combination with a bias
#pr = 1/(1+exp(-z))         # pass through an inv-logit function
#y = rbinom(1000,1,pr)      # bernoulli response variable
 
#dt <- data.frame(id = sprintf('%05d', 1:length(y)), y = y, x1 = x1, x2 = x2)
#write.table(dt, 'KCBML/data/dt.csv', row.names = F, col.names = T, sep = ',', fileEncoding = 'CP949')


